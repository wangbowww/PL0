#! /bin/bash
g++ -O2 main.cpp -o Compiler
g++ -O2 interpreter.cpp -o Interpreter 