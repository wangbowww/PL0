#! /bin/bash
g++ -O2 main.cpp -o Main